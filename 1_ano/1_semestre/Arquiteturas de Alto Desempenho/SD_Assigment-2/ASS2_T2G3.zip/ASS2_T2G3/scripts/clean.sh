rm -rf *.zip
rm -rf */*/*.class
rm -rf */*.class
rm -rf generalRepository assaultParty concentrationSite controlSite museum ordinaryThieves masterThief