/**
 * Common Infrastructure
 */

package commInfra;
